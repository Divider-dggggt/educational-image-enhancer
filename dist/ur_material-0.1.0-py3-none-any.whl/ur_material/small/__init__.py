from .functions import ink_on_paper, ink_on_paper_light, ink_bleed, low_quality\
, erosed_light, erosed_heavy, low_quality_on_paper, noised, cutted, erosed_cutted